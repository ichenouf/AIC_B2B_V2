const config = {
  dbConfig:{
      host     : 'localhost',
      user     : 'root',
      password : 'root',
      database : 'aic',
      port:8888
    }
}

module.exports = config;