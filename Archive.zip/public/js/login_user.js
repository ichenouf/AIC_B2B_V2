

//! /////////////////////////////////////////////////////////// 
//! //////////////////!   READY   //////////////////////////
//! ///////////////////////////////////////////////////////////

$(document).ready(  async function () {


});






//! /////////////////////////////////////////////////////////// 
//! //////////////////!  LOGIN  //////////////////////////
//! ///////////////////////////////////////////////////////////


onClick('#login',function() {
    if(!check_form('.form_login_container'))return  
    login()
});



async function login(){
   
    var username= $("#phone").val()
    var password= $("#password").val()
    var type= "users"
    var data={username,password,type}
    var option = {
        type: "POST",
        url: `/auth`,
        cache: false,
        data: data,
      };
      console.log(data)
    var receved_data = await $.ajax(option);
    console.log(receved_data)
    if( receved_data && receved_data.ok){
        // alert()
      window.location.href =`/app`
    }
    console.log(data)
    
} 
